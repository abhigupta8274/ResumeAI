# Run summary — 20260925_111946

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.2700** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 6 | 0 | 28016 | 991 | 0.033 | 15.5 |
| claim_02_stolen_bike | routed | theft | low | 6 | 0 | 26505 | 745 | 0.0302 | 10.2 |
| claim_03_water_damage | routed | property_damage | high | 6 | 0 | 27443 | 911 | 0.032 | 13.5 |
| claim_04_neighbor_injury | routed | liability | high | 6 | 0 | 27793 | 998 | 0.0328 | 15.3 |
| claim_05_auto_collision | routed | auto | high | 6 | 0 | 28686 | 1058 | 0.034 | 15.2 |
| claim_06_low_confidence_escalation | escalated | property_damage,liability | - | 6 | 1 | 28899 | 1453 | 0.0362 | 17.6 |
| claim_07_tree_falls_on_car | routed | auto | medium | 7 | 1 | 33244 | 1175 | 0.0391 | 18.0 |
| claim_08_minor_porch_damage | routed | property_damage | low | 6 | 0 | 28028 | 952 | 0.0328 | 13.9 |
